# Frame Window Detector

Experimental first build for Geometry Dash 2.2081 Android and Geode v5.10.1.

This build displays a 240-step-per-second counter while a level is running. It does not change the game's FPS, physics, or physics bypass settings.
