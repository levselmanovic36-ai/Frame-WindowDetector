# Frame Window Detector v0.1.0

Official Geode-template-style project for Geometry Dash Android 2.2081 / Geode v5.10.1.

Build for Android64 with:

    geode sdk install-binaries -p android64
    geode build -p android64

The resulting `.geode` is produced in the Android build directory and can be copied to the Geode mods directory.
