# Changelog

## v0.1.0
- Initial 240 TPS display prototype.
